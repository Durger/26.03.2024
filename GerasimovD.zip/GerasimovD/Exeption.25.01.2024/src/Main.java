public class Main {
    public static void main(String[] args) {
        foo();

        }
    }
   static Object object;
    public static void foo(){
        try{
            System.out.println(object.toString());
            System.out.println(1/0);
        }
     catch(Exception e){
            System.out.println("Mistake!!!" + e);
        }
        catch(ArithmeticException e){
            System.out.println("You can't divide by zero!!!" + e);
        }
        catch(NullPointerException e){
            System.out.println("Object equal null!!!" + e);
        }
        finally{

        }
        throw new NullPointerException();
    }
}