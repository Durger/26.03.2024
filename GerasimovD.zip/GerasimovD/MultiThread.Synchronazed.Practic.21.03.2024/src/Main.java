import java.util.Random;
import java.util.logging.Logger;

public class Main {
    public static void main(String[] args) {
        //Задача.1
        //При старте приложения запускаются три потока. Первый поток заполняет массив случайными числами.
        //Два других потока ожидают заполнения. Когда массив заполнен оба потока запускаются. Первый поток находит
        //сумму элементов массива, второй поток среднеарифметическое значение в массиве. Полученный массив, сумма
        //и среднеарифметическое возвращаются в метод main, где должны быть отображены.


        int[] array = new int[10];
        Thread threadfillArray = new Thread(()->fillArray(array));  //cjсоздание потока методом fillArray
        Thread threadcalcultSum = new Thread(()->{
            try {
                threadfillArray.join();
                int sum = calcultSum(array);
                System.out.println("Sum of elemets of massive = " + sum);
            }
            catch (InterruptedException e){
                e.printStackTrace();
            }
        });
        Thread threadcalculatorAverage = new Thread(()->{
            try {
             threadfillArray.join();
             double avarage = calculatorAverage(array);
                System.out.println("Averege = " + avarage);
            }
            catch (InterruptedException e){
                e.printStackTrace();
            }
        });
        threadfillArray.start();
        threadcalcultSum.start();
        threadcalculatorAverage.start();

        System.out.println("Mass: \n");
        for (int i = 0; i < array.length; i++){
            System.out.print(array[i] + " ");
        }
        System.out.println("\n");
    }
    //массив Рандома
    public static void fillArray (int[] array ){
        Random r = new Random();
        for (int i = 0; i < array.length; i++){
            array[i] = r.nextInt(100);
        }
    }
    public static int calcultSum(int [] array){
        int sum = 0;
        for (int i = 0; i < array.length; i++){
            sum+=array[i];
        }
        return  sum;
    }
    //подсчет среднего значения
    public static double calculatorAverage(int[] array){
        int sum = calcultSum(array);
        return  (double) sum / array.length;
    }
}