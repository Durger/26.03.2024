public interface IShow {

    void Print();

    void Print(String info);



}
