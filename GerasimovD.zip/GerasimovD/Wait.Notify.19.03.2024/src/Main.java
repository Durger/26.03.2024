import jdk.incubator.vector.VectorOperators;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

//Передача из файла в файл потоками

public class Main {
    public static String line = "";


    public static void main(String[] args) {
        Object locker = new Object();
        MyReader reader = new MyReader("lines.txt", locker);
        MyWriter writer = new MyWriter("lines_out.txt", locker);
        Thread t1 = new Thread(reader);
        Thread t2 = new Thread(writer);
        t1.setDaemon(true);
        t2.setDaemon(true);
        t2.start();
        try {
            Thread.sleep(1000);
        }
        catch (InterruptedException e){
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, e);
        }
        t1.start();
        try {
            t1.join();
            t2.join();
        }
        catch (InterruptedException e){
            e.printStackTrace();
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, e);
        }


    }
}
class MyWriter implements Runnable {
    FileWriter fw = null;
    Object locker;

    public MyWriter(String filePath, Object locker) {
        try {
            this.fw = new FileWriter(filePath, true);
            this.locker = locker;
        } catch (IOException e) {
            Logger.getLogger(MyWriter.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    @Override
    public void run() {
        synchronized (locker) {
            while (Main.line != "exit") {
                try {
                    locker.wait();
                    if (Main.line != "exit") {
                        fw.write(Main.line + System.getProperty("line.separator"));
                    }
                    System.out.println("*****Written line: " + Main.line);
                    locker.notify();
                } catch (IOException e) {
                    Logger.getLogger(MyWriter.class.getName()).log(Level.SEVERE, null, e);
                } catch (InterruptedException e) {
                    Logger.getLogger(MyWriter.class.getName()).log(Level.SEVERE, null, e);
                }
            }
            try {
                fw.close();
            } catch (IOException e) {
                Logger.getLogger(MyWriter.class.getName()).log(Level.SEVERE, null, e);
            }
        }

    }
}


class MyReader implements Runnable {
    FileReader fr = null;
    Object locker;

    public MyReader(String filePath, Object locker) {
        try {
            this.fr = new FileReader(filePath);
            this.locker = locker;
        } catch (FileNotFoundException e) {
            Logger.getLogger(MyReader.class.getName()).log(Level.SEVERE, null, e);
        }
    }


    @Override
    public void run() {
        int lineCount = 0;
        String str = "";
        BufferedReader br = new BufferedReader(fr);
        try {
            while ((str = br.readLine()) != null) {
                System.out.println("Reader: " + str);
                if ((lineCount++) % 2 == 0) {
                    synchronized (locker) {
                        Main.line = str;
                        locker.notify();
                        locker.wait();
                    }
                }
            }
            synchronized (locker) {
                Main.line = "exit";
                locker.notify();
                locker.wait();
            }
        } catch (IOException e) {
            Logger.getLogger(MyReader.class.getName()).log(Level.SEVERE, null, e);
        } catch (InterruptedException e) {
            Logger.getLogger(MyReader.class.getName()).log(Level.SEVERE, null, e);
        } finally {
            try {
                fr.close();
            } catch (IOException e) {
                Logger.getLogger(MyReader.class.getName()).log(Level.SEVERE, null, e);
            }
        }
    }
}



