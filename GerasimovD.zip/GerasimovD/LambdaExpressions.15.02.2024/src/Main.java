// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.


//Пример.2


//Пример.2-3
//interface MyInterface{
    //double getPiValue();
   // String reverse (String n);
//@FunctionalInterface
//interface MyInterface<T>{
//    T func(T t);
//}
//
////Практика.1
//@FunctionalInterface
//interface CalInt{
//   int calInt (int a, int b);
//}
//@FunctionalInterface
//interface ContStr{
//    String func(String a, String b);
//}

import java.time.LocalDate;
import java.util.Date;
import java.util.Locale;

@FunctionalInterface
interface CalInt2{
    int calInt2 (int a, int b, int c);
}
@FunctionalInterface
interface CurrentDateAndTime{
    void printDate();
}

@FunctionalInterface
interface Calc{
    int calcul (int a, int b);
}

@FunctionalInterface
interface Factor{
    int calcul (int a);
}


public class Main {
    public static void main(String[] args) {

        //Пример1
  /*  }
    double getPiValue(){
        return 3.1445;
    }
    //double getPiValue2()->3.1415;
    //()->System.out.println("hjhklhlih")*/


        //Пример.2
       /* MyInterface ref;
        ref = () -> 3.1415;
        System.out.println("Значение числа Pi = " + ref.getPiValue());*/

        //Пример.3
          /*  MyInterface ref = (str)->{
            String result = "";
            for(int i = str.length() - 1; i>=0; i--){
                result += str.charAt(i);
            }
                return result;

        };
        System.out.println("Лямбда выражение " + ref.reverse("samsung"));*/

        //Пример.4
       /* MyInterface <String> revers = (str)->{
            String result = "";
            for(int i = str.length() - 1; i>=0; i--){
                result += str.charAt(i);
            }
            return result;
        };
        System.out.println("Лямбда выражение " + revers.func("asus"));

        MyInterface <Integer> factorial = (n)->{
            int result = 1;
            for(int i = 1; i<=n; i++){
                result = i * result;
            }
            return result;
        };
        System.out.println("Факториал от 5 = :" + factorial.func(5));*/

//Практика.1. сумма чисел
//        CalInt2 calInt = (n, v)->{
//            return n + v;
//        };
//        System.out.println("Сумма чисел = :" + calInt.calInt(4, 5));
//
//
//        //Практика.2.сложить 2 строки
//
//        ContStr contStr = (str1, str2)->{
//            return str1 + str2;
//        };
//        System.out.println("Конкатенация строк: " + contStr.func("Привет", "Балет"));


        //Практика.3-35.Задание.1
//Создайте и вызовите следующие лямбда-выражения:
//■ Подсчет суммы трёх целых чисел;
//■ Подсчет произведения трёх целых чисел;
//■ Вывод текущего времени;
//■ Вывод текущей даты.

        //Подсчет суммы трёх целых чисел;
        CalInt2 calInt2 = (x, y, z) -> {
            return x + y + z;
        };
        System.out.println("Сумма трех чисел = " + calInt2.calInt2(4, 5, 9));

        //Подсчет произведения трёх целых чисел;
        CalInt2 calInt3 = (x, y, z) -> {
            return x * y * z;
        };
        System.out.println("Произведение трех чисел = " + calInt3.calInt2(4, 5, 9));

        //Вывод текущего времени;
        CurrentDateAndTime currentTime = () -> {
            Date date = new Date();
            System.out.println("Текущее время:" + date);
        };
        currentTime.printDate();
//Вывод текущей даты.
        CurrentDateAndTime currentDate = () -> {
            LocalDate localeDate = LocalDate.now();
            System.out.println("Текущая дата: " + localeDate);
        };
        currentDate.printDate();


        //Практика.3-35.Задание.2
        //Создайте и вызовите следующие лямбда-выражения:
        //■ Максимум из двух;
        //■ Минимум из двух;
        //■ Факториал числа;
        //■ Проверка простое число или нет.

        //■ Максимум из двух;
        Calc cal = (z, x) -> {
            if (z > x) {
                return z;
            } else {
                return x;
            }
        };
        System.out.println("Максимум из двух чисел: " + cal.calcul(50, 21));

        //Минимум из двух;
        Calc cal1 = (z, x) -> {
            if (z > x) {
                return x;
            } else {
                return z;
            }
        };
        System.out.println("Минимум из двух чисел: " + cal1.calcul(50, 21));

        //Факториал числа;
        Factor cal2 = (z)->{
            int result = 1;
            for (int i = 1; i <= z; i ++){
                result *= i;
            }
            return result;
        };
        System.out.println("Факториал: " + cal2.calcul(5));

        //Проверка простое число или нет
        Factor factor = (z)->{
            if (z <= 1){
                return 0;
            }
            for (int i = 2; i < Math.sqrt(z); i++){
                if(z%i==0){
                    return 0;
                }
            }
            return 1;
        };
        if(factor.calcul(29)==0){
            System.out.println("Не является!");
            }
        else {
            System.out.println("Является");
        }






    }

}