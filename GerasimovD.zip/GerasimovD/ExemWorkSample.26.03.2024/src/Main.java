import java.util.ArrayList;
import java.util.List;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {

        //Выпускная работа 4
    Wallet wallet1 = new Wallet ("Wallet 1", 500);
    Wallet wallet2 = new Wallet ("Wallet 2", 1000);

    CreditCard creditCard1 = new CreditCard("Card 1", 800);
    CreditCard creditCard2 = new CreditCard("Card 2", 800);

    wallet1.dissplayWalletState();
    wallet2.dissplayWalletState();

    creditCard1.dissplayCreditCard();
    creditCard2.dissplayCreditCard();

    }
}

//Класс для кошелька
class Wallet{
    private String name;
    private double amount;
    public Wallet (String name, double amount){
        this.amount = amount;
        this.name = name;
    }
    public double getAmount() {
        return this.amount;
    }

    public String getName() {
        return this.name;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void dissplayWalletState() {
        System.out.printf("Name a wallet: " + name);
        System.out.printf("Summ a wallet: " + amount);
        System.out.printf("*********************************");

        //Другая информация о кошельке
    }
    }
//Это класс для кредитной карты
class CreditCard{
    private String name;
    private double amount;
    public CreditCard (String name, double amount){
        this.amount = amount;
        this.name = name;
    }
    public double getAmount() {
        return this.amount;
    }

    public String getName() {
        return this.name;
    }
    public void setAmount(double amount) {
        this.amount = amount;
    }

    public void setName(String name) {
        this.name = name;
    }
    public void dissplayCreditCard() {
        System.out.printf("Name a credit cart: " + name);
        System.out.printf("Summ on credit card: " + amount);
        System.out.printf("*********************************");

        //Другая информация о карте
    }
}

//Расходы
class Expenses {
    private String name;
    private double amount;

    public Expenses(String name, double amount) {
        this.amount = amount;
        this.name = name;
    }

    public double getAmount() {
        return this.amount;
    }

    public String getName() {
        return this.name;
    }
    public void setAmount(double amount) {
        this.amount = amount;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void dissplayExpenses() {
        System.out.printf("Expenses cart: " + name);
        System.out.printf("Summ expenseson credit card: " + amount);
        System.out.printf("*********************************");

        //Другая информация о расходах
    }
}
class ExpensesPotential {
    private String name;
    private double amount;

    public ExpensesPotential(String name, double amount) {
        this.amount = amount;
        this.name = name;
    }

    public double getAmount() {
        return this.amount;
    }

    public String getName() {
        return this.name;
    }
    public void setAmount(double amount) {
        this.amount = amount;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void dissplayExpensesPotential() {
        System.out.printf("Name expenses potential cart: " + name);
        System.out.printf("Sum potential expenseson : " + amount);
        System.out.printf("*********************************");

        //Другая информация о расходах
    }
}

//Потенциальный доход
class PotentialIncome {
    private String name;
    private double amount;

    public PotentialIncome(String name, double amount) {
        this.amount = amount;
        this.name = name;
    }

    public double getAmount() {
        return this.amount;
    }

    public String getName() {
        return this.name;
    }
    public void setAmount(double amount) {
        this.amount = amount;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void dissplayPotentialIncome() {
        System.out.printf("Name potential income: " + name);
        System.out.printf("Sum potential income : " + amount);
        System.out.printf("*********************************");

        //Другая информация о расходах
    }
}

class FinancialAccountingSystem {
    private List<Wallet> wallets;
    private List<CreditCard> creditCards;
    private List<Expenses> expenses;
    private List<ExpensesPotential> expensesPotentials;
    private List<PotentialIncome> potentialIncomes;

    public FinancialAccountingSystem() {
        wallets = new ArrayList<>();
        creditCards = new ArrayList<>();
        expenses = new ArrayList<>();
        expensesPotentials = new ArrayList<>();
        potentialIncomes = new ArrayList<>();
    }

    public double SumOfAllWalletsAndCreditsCards() {
        double sum1 = 0;
        for (int i = 0; i < wallets.size(); i++) {
            sum1 += wallets.get(i).getAmount();
        }
        double sum2 = 0;
        for (int i = 0; i < wallets.size(); i++) {
            sum2 += wallets.get(i).getAmount();
        }
        return sum1 + sum2;
    }

    public double SumOfAllWallets() {
        double sum = 0;
        for (int i = 0; i < wallets.size(); i++) {
            sum += wallets.get(i).getAmount();
        }
        return sum;
    }

    public double SumOfAllCreditsCards() {
        double sum = 0;
        for (int i = 0; i < creditCards.size(); i++) {
            sum += creditCards.get(i).getAmount();
        }
        return sum;
    }

    public double SumOfAllExpenses() {
        double sum = 0;
        for (int i = 0; i < expenses.size(); i++) {
            sum += expenses.get(i).getAmount();
        }
        return sum;
    }

    public double SumOfAllExpensesPotential() {
        double sum = 0;
        for (int i = 0; i < expensesPotentials.size(); i++) {
            sum += expensesPotentials.get(i).getAmount();
        }
        return sum;
    }

    public double SumOfAllPotentialIncome() {
        double sum = 0;
        for (int i = 0; i < potentialIncomes.size(); i++) {
            sum += potentialIncomes.get(i).getAmount();
        }
        return sum;
    }

    public void EditWallet(String name, double amount) {
        for (int i = 0; i < wallets.size(); i++) {
            if (wallets.get(i).getName().equals(name)) {
                potentialIncomes.get(i).setAmount(amount);
            }
        }
    }

    public void EditCreditCard(String name, double amount) {
        for (int i = 0; i < creditCards.size(); i++) {
            if (creditCards.get(i).getName().equals(name)) {
                creditCards.get(i).setAmount(amount);
            }
        }
    }

    public void ShowListWallet(List<Wallet> wallets) {
        for (int i = 0; i < wallets.size(); i++) {
            wallets.get(i).dissplayWalletState();
        }
    }

    public void ShowCreditCard(List<CreditCard> creditCards) {
        for (int i = 0; i < creditCards.size(); i++) {
            creditCards.get(i).dissplayCreditCard();
        }
    }

    public void ShowExpenses(List<Expenses> expenses) {
        for (int i = 0; i < expenses.size(); i++) {
            expenses.get(i).dissplayExpenses();
        }
    }

    public void ShowxpensesPotential(List<ExpensesPotential> expensesPotentials) {
        for (int i = 0; i < expensesPotentials.size(); i++) {
           expensesPotentials.get(i).dissplayExpensesPotential();
        }
    }

    public void ShowPotentialIncome(List<PotentialIncome> potentialIncomes) {
        for (int i = 0; i < potentialIncomes.size(); i++) {
            potentialIncomes.get(i).dissplayPotentialIncome();
        }
    }
}

